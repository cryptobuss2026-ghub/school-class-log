"""
Weekly Teacher Class Logging App
================================
Streamlit + Google Sheets (gspread).

Tabs
  1. Register      - teacher signs up (name, email, PIN, sections, subjects)
  2. Log Lessons   - teacher logs in and submits what they taught this week
  3. Admin         - password-protected view of logs / registrations

Data layout
  * Teachers_Register spreadsheet  -> worksheet "Teachers"
  * One spreadsheet PER grade-section (IDs in secrets.toml) -> worksheet "Log"

All configuration (sheet IDs, subjects, timezone, admin password) lives in
.streamlit/secrets.toml  -> see secrets.toml.example
"""

import hashlib
import hmac
import re
import secrets as pysecrets
from datetime import datetime
from zoneinfo import ZoneInfo

import gspread
import pandas as pd
import streamlit as st
from google.oauth2.service_account import Credentials

# ----------------------------------------------------------------------------
# CONFIG
# ----------------------------------------------------------------------------
st.set_page_config(page_title="Weekly Class Log", page_icon="📚", layout="centered")

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]

TEACHERS_TAB = "Teachers"
TEACHERS_HEADERS = ["Registered At", "Name", "Email", "PIN Hash", "Sections", "Subjects"]

LOG_TAB = "Log"
LOG_HEADERS = ["Timestamp", "Week Number", "Teacher Name", "Subject", "Topics / Lessons Taught"]

DEFAULT_SUBJECTS = [
    "English", "Urdu", "Mathematics", "Science", "Social Studies",
    "Islamiyat", "Computer Science", "Art", "Physical Education",
]

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def cfg(section: str, key: str, default=None):
    """Safe accessor for st.secrets[section][key]."""
    try:
        return st.secrets[section][key]
    except Exception:
        return default


TZ = ZoneInfo(cfg("app", "timezone", "Asia/Karachi"))
SUBJECTS = list(cfg("app", "subjects", DEFAULT_SUBJECTS))

# ---------------------------------------------------------------------------
# GRADE/SECTION -> GOOGLE SHEET ID MAPPING
# Loaded from [section_sheets] in secrets.toml, e.g.
#   "Grade 1 - Sec A" = "1AbC...sheetId"
# ---------------------------------------------------------------------------
SECTION_SHEETS: dict[str, str] = dict(st.secrets.get("section_sheets", {})) if "section_sheets" in st.secrets else {}


# ----------------------------------------------------------------------------
# TIME / DEADLINE LOGIC
# ----------------------------------------------------------------------------
def now_local() -> datetime:
    return datetime.now(TZ)


def week_label(dt: datetime) -> str:
    """ISO week label, e.g. '2026-W41'. Weeks run Monday-Sunday."""
    iso = dt.isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


def submissions_open(dt: datetime) -> bool:
    """
    The school week is Monday-Saturday. Submissions are open until
    Saturday 23:59:59 and closed on Sunday (weekday() == 6).
    A new week opens on Monday 00:00.
    """
    return dt.weekday() != 6


CLOSED_MSG = "Submissions for this week closed on Saturday at 11:59 PM."


# ----------------------------------------------------------------------------
# GOOGLE SHEETS CONNECTION
# ----------------------------------------------------------------------------
@st.cache_resource
def get_client() -> gspread.Client:
    creds = Credentials.from_service_account_info(
        dict(st.secrets["gcp_service_account"]), scopes=SCOPES
    )
    return gspread.authorize(creds)


@st.cache_resource(ttl=3600)
def get_ws(sheet_id: str, tab: str, headers: tuple) -> gspread.Worksheet:
    """Open a worksheet, creating the tab and header row if missing."""
    sh = get_client().open_by_key(sheet_id)
    try:
        ws = sh.worksheet(tab)
    except gspread.WorksheetNotFound:
        ws = sh.add_worksheet(title=tab, rows=1000, cols=len(headers))
    if not ws.row_values(1):
        ws.append_row(list(headers), value_input_option="RAW")
    return ws


def teachers_ws() -> gspread.Worksheet:
    return get_ws(st.secrets["sheets"]["teachers_register_id"], TEACHERS_TAB, tuple(TEACHERS_HEADERS))


def log_ws(section: str) -> gspread.Worksheet:
    """Dynamic routing: pick the spreadsheet that belongs to this section."""
    sheet_id = SECTION_SHEETS.get(section)
    if not sheet_id:
        raise KeyError(f"No Google Sheet configured for '{section}'")
    return get_ws(sheet_id, LOG_TAB, tuple(LOG_HEADERS))


# ----------------------------------------------------------------------------
# AUTH HELPERS (salted PBKDF2 - PINs are never stored in plain text)
# ----------------------------------------------------------------------------
def hash_pin(pin: str) -> str:
    salt = pysecrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), 200_000).hex()
    return f"{salt}${digest}"


def verify_pin(pin: str, stored: str) -> bool:
    try:
        salt, digest = stored.split("$")
        test = hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), 200_000).hex()
        return hmac.compare_digest(test, digest)
    except Exception:
        return False


def find_teacher(email: str):
    email = email.strip().lower()
    for row in teachers_ws().get_all_records():
        if str(row.get("Email", "")).strip().lower() == email:
            return row
    return None


def split_list(value: str) -> list[str]:
    return [v.strip() for v in str(value).split(";") if v.strip()]


# ----------------------------------------------------------------------------
# UI: HEADER + SETUP CHECK
# ----------------------------------------------------------------------------
st.title("📚 Weekly Class Log")
now = now_local()
st.caption(f"{now:%A, %d %b %Y %I:%M %p} · Current week: **{week_label(now)}**")

if not SECTION_SHEETS or "gcp_service_account" not in st.secrets:
    st.error("App is not configured yet. Add your secrets (see secrets.toml.example).")
    st.stop()

tab_reg, tab_log, tab_admin = st.tabs(["📝 Register", "✏️ Log Lessons", "🔒 Admin"])

# ----------------------------------------------------------------------------
# TAB 1 - REGISTER
# ----------------------------------------------------------------------------
with tab_reg:
    st.subheader("Teacher Registration")
    with st.form("register_form", clear_on_submit=True):
        name = st.text_input("Full name")
        email = st.text_input("Email")
        pin = st.text_input("Choose a PIN / password (min 6 characters)", type="password")
        pin2 = st.text_input("Confirm PIN / password", type="password")
        sections = st.multiselect("Grade / Section(s) you teach", list(SECTION_SHEETS.keys()))
        subjects = st.multiselect("Subject(s) you teach", SUBJECTS)
        go = st.form_submit_button("Register")

    if go:
        if not name.strip():
            st.error("Please enter your name.")
        elif not EMAIL_RE.match(email.strip()):
            st.error("Please enter a valid email address.")
        elif len(pin) < 6:
            st.error("PIN / password must be at least 6 characters.")
        elif pin != pin2:
            st.error("PIN / password entries do not match.")
        elif not sections or not subjects:
            st.error("Select at least one section and one subject.")
        else:
            try:
                if find_teacher(email):
                    st.error("This email is already registered. Use the Log Lessons tab to sign in.")
                else:
                    teachers_ws().append_row(
                        [
                            now_local().strftime("%Y-%m-%d %H:%M:%S"),
                            name.strip(),
                            email.strip().lower(),
                            hash_pin(pin),
                            "; ".join(sections),
                            "; ".join(subjects),
                        ],
                        value_input_option="RAW",
                    )
                    st.success("Registered! You can now sign in on the Log Lessons tab.")
            except Exception as e:
                st.error(f"Could not save registration: {e}")

# ----------------------------------------------------------------------------
# TAB 2 - LOG LESSONS
# ----------------------------------------------------------------------------
with tab_log:
    st.subheader("Weekly Lesson Log")
    teacher = st.session_state.get("teacher")

    if not teacher:
        with st.form("login_form"):
            l_email = st.text_input("Email")
            l_pin = st.text_input("PIN / password", type="password")
            login = st.form_submit_button("Sign in")
        if login:
            try:
                rec = find_teacher(l_email)
                if rec and verify_pin(l_pin, str(rec["PIN Hash"])):
                    st.session_state["teacher"] = {
                        "name": rec["Name"],
                        "email": rec["Email"],
                        "sections": split_list(rec["Sections"]),
                        "subjects": split_list(rec["Subjects"]),
                    }
                    st.rerun()
                else:
                    st.error("Invalid email or PIN.")
            except Exception as e:
                st.error(f"Sign-in failed: {e}")
    else:
        c1, c2 = st.columns([3, 1])
        c1.write(f"Signed in as **{teacher['name']}**")
        if c2.button("Sign out"):
            st.session_state.pop("teacher")
            st.rerun()

        if not submissions_open(now_local()):
            st.warning(CLOSED_MSG)
        else:
            with st.form("log_form", clear_on_submit=True):
                section = st.selectbox("Grade / Section", teacher["sections"])
                subject = st.selectbox("Subject", teacher["subjects"])
                topics = st.text_area(
                    "Topics / lessons taught this week",
                    height=160,
                    placeholder="e.g. Fractions: adding unlike denominators; Exercise 4.2",
                )
                submit = st.form_submit_button("Submit log")

            if submit:
                ts = now_local()  # re-check at submit time (form may have been open overnight)
                if not submissions_open(ts):
                    st.warning(CLOSED_MSG)
                elif len(topics.strip()) < 5:
                    st.error("Please describe what you taught.")
                else:
                    try:
                        log_ws(section).append_row(
                            [
                                ts.strftime("%Y-%m-%d %H:%M:%S"),
                                week_label(ts),
                                teacher["name"],
                                subject,
                                topics.strip(),
                            ],
                            value_input_option="RAW",  # RAW stops formula injection
                        )
                        st.success(f"Saved to {section} for {week_label(ts)}. ✅")
                    except Exception as e:
                        st.error(f"Could not save log: {e}")

# ----------------------------------------------------------------------------
# TAB 3 - ADMIN
# ----------------------------------------------------------------------------
with tab_admin:
    st.subheader("Admin View")
    admin_pw = cfg("admin", "password")

    if not st.session_state.get("is_admin"):
        with st.form("admin_form"):
            pw = st.text_input("Admin password", type="password")
            ok = st.form_submit_button("Unlock")
        if ok:
            if admin_pw and hmac.compare_digest(pw, str(admin_pw)):
                st.session_state["is_admin"] = True
                st.rerun()
            else:
                st.error("Wrong password.")
    else:
        if st.button("Lock admin"):
            st.session_state["is_admin"] = False
            st.rerun()

        view = st.radio("View", ["Logs by section", "Submission status", "Registered teachers"], horizontal=True)

        if view == "Logs by section":
            section = st.selectbox("Section", list(SECTION_SHEETS.keys()), key="adm_sec")
            try:
                df = pd.DataFrame(log_ws(section).get_all_records())
                if df.empty:
                    st.info("No entries yet.")
                else:
                    weeks = sorted(df["Week Number"].unique(), reverse=True)
                    wk = st.selectbox("Week", ["All"] + weeks)
                    if wk != "All":
                        df = df[df["Week Number"] == wk]
                    st.dataframe(df, use_container_width=True, hide_index=True)
                    st.download_button("Download CSV", df.to_csv(index=False), f"{section}.csv", "text/csv")
            except Exception as e:
                st.error(f"Could not load logs: {e}")

        elif view == "Submission status":
            wk = week_label(now_local())
            st.write(f"Sections with at least one entry for **{wk}**:")
            rows = []
            for sec in SECTION_SHEETS:
                try:
                    recs = log_ws(sec).get_all_records()
                    n = sum(1 for r in recs if r.get("Week Number") == wk)
                except Exception:
                    n = -1
                rows.append({"Section": sec, "Entries this week": n if n >= 0 else "error"})
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

        else:
            try:
                df = pd.DataFrame(teachers_ws().get_all_records())
                if not df.empty:
                    df = df.drop(columns=["PIN Hash"], errors="ignore")
                st.dataframe(df, use_container_width=True, hide_index=True)
            except Exception as e:
                st.error(f"Could not load teachers: {e}")
